//
//  Singleton.h
//  SingletonDemo
//
//  Created by define on 16/3/22.
//  Copyright © 2016年 LiuShaoQiang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Singleton : NSObject


@property (nonatomic,strong)NSString *myLove;
+(id)shareSingleton;


@end
