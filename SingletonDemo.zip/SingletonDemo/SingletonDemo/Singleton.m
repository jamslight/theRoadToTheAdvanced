//
//  Singleton.m
//  SingletonDemo
//
//  Created by define on 16/3/22.
//  Copyright © 2016年 LiuShaoQiang. All rights reserved.
//

#import "Singleton.h"

@implementation Singleton

//基于GCD写的单例
+(id)shareSingleton{

    static Singleton *single = nil;
    
    static dispatch_once_t oneTake;
    
    dispatch_once(&oneTake, ^{
        single = [[self alloc]init];
    });
    
    return single;
}


- (id)init{
    if (self = [super init]) {
        _myLove = [NSString stringWithFormat:@"love"];
    }
    return self;
}


@end
