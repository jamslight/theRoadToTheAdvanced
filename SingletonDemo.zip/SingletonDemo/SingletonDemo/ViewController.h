//
//  ViewController.h
//  SingletonDemo
//
//  Created by define on 16/3/22.
//  Copyright © 2016年 LiuShaoQiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

