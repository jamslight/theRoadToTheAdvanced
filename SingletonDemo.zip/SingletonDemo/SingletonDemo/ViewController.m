//
//  ViewController.m
//  SingletonDemo
//
//  Created by define on 16/3/22.
//  Copyright © 2016年 LiuShaoQiang. All rights reserved.
//

#import "ViewController.h"
#import "Singleton.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    Singleton *single = [Singleton shareSingleton];
    NSLog(@"myLove%@",single.myLove);
    
    single.myLove = @"youLove";
    NSLog(@"%@",single.myLove);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
